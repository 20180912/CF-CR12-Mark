    <?php wp_footer();?>
    <div class="container d-flex justify-content-center">

        <i class="fab fa-2x m-2 footer-icon fa-instagram"></i>
        <i class="fab fa-2x m-2 footer-icon fa-facebook-f"></i>
        <i class="fab fa-2x m-2 footer-icon fa-pinterest-p"></i>
        <i class="fab fa-2x m-2 footer-icon fa-vimeo-v"></i>
        <i class="fab fa-2x m-2 footer-icon fa-twitter"></i>

  </div>

    </div>
</body>

</html>