<div class="container">

    <?php get_header();?>

    <div class="row">

        <img class="col-12" src="<?php echo get_template_directory_uri(); ?>/img/mountains.jpg" alt="Mountains">

    </div>

    <div class="text-center my-5">
        <p class="display-1">Mount Everest</p>
        <p class="h5">your travel experts</p>
    </div>

    <p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet. Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.</p>
    
    <p class="text-center font-weight-bold">Hear what our customers have to say:</p>

    <div class="row align-items-center">
        <img src="<?php echo get_template_directory_uri(); ?>/img/man.jpg" class="rounded col-lg-3" alt="man">
        <div class="col-lg-8 p-3">
            <p class="font-italic">"I was looking for the Mount Everest all over Vienna and it wasn't there. I want my money back!"</p>    
        </div>
    </div>

    <hr>

    <?php if (have_posts()): ?> <!--  If there are pages available  -->

        <?php while (have_posts()): the_post();?> <!-- if there are pages, iterate the page in the loop -->

            <?php the_content();?><!--retrieves content-->

        <?php endwhile;?><!--end the while loop-->

    <?php endif;?> <!-- end if -->


</div>


<?php get_footer();?>