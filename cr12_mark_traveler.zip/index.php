<?php get_header();?>

<div class="container">

    <div class="text-center my-5">
        <p class="display-1">Mount Everest</p>
        <p class="h5">your travel experts</p>
    </div>

    <div class="row m-0">

        <?php if (have_posts()): ?> <!--  If there are posts available  -->

            <?php while (have_posts()): the_post();?> <!-- if there are posts, iterate the posts in the loop -->

                <div class="col-lg-3 col-md-6 col-12 p-3">

                    <div class="card" style="height: 100%;">

                        <?php $image =  wp_get_attachment_image_src(get_post_thumbnail_id($post->ID ), 'full'); ?>
                        <img src="<?php echo $image[0];?>" class="card-img-top" style="height: 15em; object-fit:cover;">

                        <div class="text-center card-body">
                            <h5 class="card-title"><?php the_title();?></h5>
                            <p><?php the_excerpt(); ?></p>
                        </div>

                        <div class="card-footer">
                            <div class="text-center">
                                <a href="<?php the_permalink();?>"><button type="button" class="btn btn-primary">Learn more</button></a>
                            </div>
                        </div>
                        
                    </div>

                </div>


            <?php endwhile;?><!--end the while loop-->

        <?php else: ?> <!-- if no posts are found then: -->

            <p>No posts found</p>  <!-- no posts found displayed -->
        <?php endif;?> <!-- end if -->

    </div>

    <hr>

    <?php if(is_active_sidebar('sidebar')):
        dynamic_sidebar('sidebar');
    endif; ?>

</div>

<?php get_footer();?>